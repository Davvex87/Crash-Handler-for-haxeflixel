3.png is your background image
5.png is your error description text font
6.png is your button text font
4.png is not in use, you can delete it if u want, i just left it here in case u want to use it :)
background example.png is just a background example ¯\_(ツ)_/¯
example.xcf is the same as background example.png, but you can open in gimp to see all the elements it uses
background.xcf is for gimp

























damn this is a terrible readme